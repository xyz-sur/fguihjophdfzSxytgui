# TopUpKu Store — Web Toko Digital + Duitku (Node.js)

Web toko produk digital untuk memenuhi persyaratan verifikasi merchant Duitku:

1. ✅ **Katalog produk** dengan deskripsi & harga Rupiah (halaman depan, sebelum login)
2. ✅ **Kontak support** — email, telepon, alamat usaha (halaman depan, sebelum login)
3. ✅ **Checkout hingga pembayaran** terintegrasi Sandbox Duitku (API v2, HMAC-SHA256)
4. ✅ **Member portal** dengan akun testing untuk tim Duitku

## Akun testing (informasikan ke tim Duitku)

| Halaman login | `https://pay.msr.my.id/login` |
|---|---|
| Email | `demo@pay.msr.my.id` |
| Password | `DemoDuitku2026` |

Ubah akun di `lib/auth.js` bila perlu.

## Alur pembelian

Katalog (publik) → Login member → Pilih produk → Pilih metode pembayaran
(diambil live dari Get Payment Method Duitku) → Bayar Sekarang → diarahkan ke
halaman pembayaran Duitku → callback masuk → status pesanan otomatis SUCCESS
→ customer kembali via halaman /return (status diverifikasi ulang ke API Duitku).

## Setup

```bash
npm install
cp .env.example .env   # isi kredensial Duitku + data usaha Anda
npm start              # http://localhost:3000
```

**Wajib diganti sebelum diajukan verifikasi** (di `.env`):
- `DUITKU_MERCHANT_CODE`, `DUITKU_API_KEY` — dari merchant portal Duitku
- `APP_BASE_URL=https://pay.msr.my.id`
- `SUPPORT_EMAIL`, `SUPPORT_PHONE`, `SUPPORT_ADDRESS` — **data usaha asli Anda**
- `SESSION_SECRET` — string acak

Produk bisa disesuaikan di `lib/products.js` (harga min. Rp 10.000).

## Callback

- Endpoint: `POST https://pay.msr.my.id/callback` (balas 200 setelah signature valid)
- Return: `GET https://pay.msr.my.id/return`
- Signature HMAC-SHA256 (formula terbaru per April 2026, MD5 obsolete)
- Whitelist IP Duitku bila pakai firewall (lihat dokumentasi callback Duitku)

## Uji di sandbox

- VA: halaman demo sukses `sandbox.duitku.com/payment/demo/demosuccesstransaction.aspx`
- Kartu kredit: VISA `4000 0000 0000 0044`, exp `03/33`, CVV `123`

## Struktur

```
├── server.js           # Express: halaman, auth, checkout, callback
├── lib/duitku.js       # Signature HMAC-SHA256 + API Duitku
├── lib/products.js     # Katalog produk (edit di sini)
├── lib/auth.js         # Login + akun testing
├── lib/store.js        # Penyimpanan pesanan (JSON)
├── public/index.html   # Katalog + kontak (sebelum login)
├── public/login.html   # Login member
├── public/member.html  # Member portal: checkout + riwayat
└── public/return.html  # Halaman setelah pembayaran
```
