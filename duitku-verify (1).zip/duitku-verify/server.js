require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');
const duitku = require('./lib/duitku');
const store = require('./lib/store');
const { PRODUCTS, findProduct } = require('./lib/products');
const { authenticate, requireLogin } = require('./lib/auth');

const app = express();
const PORT = process.env.PORT || 3000;
const APP_BASE_URL = (process.env.APP_BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');

// ====== INFO USAHA — GANTI DENGAN DATA USAHA ANDA YANG SEBENARNYA ======
const SITE = {
  brand: process.env.SITE_BRAND || 'TopUpKu Store',
  supportEmail: process.env.SUPPORT_EMAIL || 'support@pay.msr.my.id',
  supportPhone: process.env.SUPPORT_PHONE || '+62 812-3456-7890',
  supportAddress:
    process.env.SUPPORT_ADDRESS ||
    'Jl. Contoh Alamat Usaha No. 1, Kel. Contoh, Kec. Contoh, Kota Anda, Provinsi, 12345',
};

app.use(express.json());
app.use(express.urlencoded({ extended: true })); // callback Duitku: x-www-form-urlencoded
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'ganti-dengan-secret-acak-panjang',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 8 }, // 8 jam
  })
);
app.use(express.static(path.join(__dirname, 'public')));

/* ================= HALAMAN ================= */

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/member');
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});
app.get('/member', requireLogin, (req, res) =>
  res.sendFile(path.join(__dirname, 'public', 'member.html'))
);
app.get('/return', (req, res) => res.sendFile(path.join(__dirname, 'public', 'return.html')));

/* ================= AUTH ================= */

app.post('/api/login', (req, res) => {
  const user = authenticate(req.body.email, req.body.password);
  if (!user) return res.status(401).json({ error: 'Email atau password salah.' });
  req.session.user = user;
  res.json({ ok: true, user });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/me', (req, res) => {
  res.json({ user: req.session.user || null });
});

/* ================= INFO PUBLIK ================= */

app.get('/api/site-info', (req, res) => res.json(SITE));
app.get('/api/products', (req, res) => res.json(PRODUCTS));

/* ================= CHECKOUT (MEMBER) ================= */

app.post('/api/checkout', requireLogin, async (req, res) => {
  try {
    const { productId, paymentMethod, gameId } = req.body;
    const product = findProduct(productId);
    if (!product) return res.status(400).json({ error: 'Produk tidak ditemukan.' });
    if (!paymentMethod) return res.status(400).json({ error: 'Pilih metode pembayaran.' });

    const user = req.session.user;
    const merchantOrderId = `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const productDetails = `${product.name} - ${SITE.brand}`;

    const result = await duitku.createTransaction({
      merchantOrderId,
      paymentAmount: product.price,
      paymentMethod,
      productDetails,
      customerName: user.name,
      email: user.email,
      phoneNumber: user.phone,
      callbackUrl: `${APP_BASE_URL}/callback`,
      returnUrl: `${APP_BASE_URL}/return`,
      expiryPeriod: 60,
    });

    store.save(merchantOrderId, {
      merchantOrderId,
      reference: result.reference,
      amount: product.price,
      paymentMethod,
      product: { id: product.id, name: product.name },
      gameId: gameId || null,
      customer: { name: user.name, email: user.email },
      status: 'PENDING',
      statusCode: '01',
      paymentUrl: result.paymentUrl,
      vaNumber: result.vaNumber || null,
      createdAt: new Date().toISOString(),
    });

    res.json({
      merchantOrderId,
      reference: result.reference,
      paymentUrl: result.paymentUrl,
      vaNumber: result.vaNumber || null,
      amount: result.amount,
    });
  } catch (err) {
    console.error('[checkout]', err.message);
    res.status(502).json({ error: err.message });
  }
});

// Metode pembayaran aktif (dipakai di halaman checkout member)
app.get('/api/payment-methods', requireLogin, async (req, res) => {
  try {
    const amount = parseInt(req.query.amount || '10000', 10);
    res.json(await duitku.getPaymentMethods(amount));
  } catch (err) {
    console.error('[payment-methods]', err.message);
    res.status(502).json({ error: err.message });
  }
});

// Riwayat pesanan milik member yang sedang login
app.get('/api/my-orders', requireLogin, (req, res) => {
  const email = req.session.user.email;
  res.json(store.list().filter((t) => t.customer?.email === email));
});

// Cek status ke server Duitku (sumber kebenaran) + update lokal
app.get('/api/status/:orderId', async (req, res) => {
  try {
    const { orderId } = req.params;
    const remote = await duitku.checkTransaction(orderId);
    const statusMap = { '00': 'SUCCESS', '01': 'PENDING', '02': 'CANCELED' };
    if (store.get(orderId)) {
      store.save(orderId, {
        status: statusMap[remote.statusCode] || remote.statusMessage,
        statusCode: remote.statusCode,
        fee: remote.fee,
      });
    }
    res.json({ local: store.get(orderId), duitku: remote });
  } catch (err) {
    console.error('[status]', err.message);
    res.status(502).json({ error: err.message });
  }
});

/* ================= CALLBACK DUITKU ================= */
// POST x-www-form-urlencoded; wajib balas HTTP 200 secepatnya
app.post('/callback', (req, res) => {
  const { merchantCode, amount, merchantOrderId, resultCode, reference, signature } = req.body;
  console.log('[callback] diterima:', JSON.stringify(req.body));

  const valid = duitku.verifyCallbackSignature({ merchantCode, amount, merchantOrderId, signature });
  if (!valid) {
    console.warn('[callback] BAD SIGNATURE untuk order', merchantOrderId);
    return res.status(400).send('Bad Signature');
  }

  const status = resultCode === '00' ? 'SUCCESS' : 'FAILED';
  store.save(merchantOrderId, {
    merchantOrderId,
    reference,
    status,
    statusCode: resultCode,
    callbackReceivedAt: new Date().toISOString(),
    callbackPayload: req.body,
  });

  // Wajib segera balas 200 agar Duitku tidak menganggap callback gagal / mengirim ulang
  res.status(200).send('OK');

  // Praktik terbaik: verifikasi ulang ke API cek transaksi (di background)
  duitku
    .checkTransaction(merchantOrderId)
    .then((check) => {
      const statusMap = { '00': 'SUCCESS', '01': 'PENDING', '02': 'CANCELED' };
      store.save(merchantOrderId, {
        status: statusMap[check.statusCode] || check.statusMessage,
        statusCode: check.statusCode,
        fee: check.fee,
      });
      console.log(`[callback] order ${merchantOrderId} terverifikasi: ${check.statusMessage}`);
    })
    .catch((err) => console.warn('[callback] gagal cek ulang status:', err.message));
});

app.listen(PORT, () => {
  console.log('--------------------------------------------------');
  console.log(`  ${SITE.brand} berjalan di http://localhost:${PORT}`);
  console.log(`  Environment Duitku : ${duitku.ENV} (${duitku.BASE_URL})`);
  console.log(`  Merchant Code      : ${duitku.MERCHANT_CODE || '(belum diisi!)'}`);
  console.log(`  Callback URL       : ${APP_BASE_URL}/callback`);
  console.log(`  Akun testing       : demo@pay.msr.my.id / DemoDuitku2026`);
  console.log('--------------------------------------------------');
});
