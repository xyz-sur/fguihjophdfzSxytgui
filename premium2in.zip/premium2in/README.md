# premium2in

Toko produk digital (pulsa, paket data, e-wallet, token PLN, **aplikasi premium**) berbasis Node.js.
Fitur: registrasi pakai nomor WhatsApp / username Telegram, saldo & deposit multi payment gateway,
order via **H2H** (Atlantic-Pedia + slot QiosPay/OrderKuota), **pembelian terjadwal** (harian/mingguan/bulanan),
dan panel admin. Semua provider punya **mode simulasi (mock)** agar web langsung jalan tanpa API key —
penting untuk lolos verifikasi H2H Atlantic-Pedia.

## Menjalankan (lokal)

```bash
npm install
cp .env.example .env      # lalu edit .env
npm start                 # http://localhost:3000
```

Login admin default: **admin / admin123** (ubah di `.env`).

> Untuk uji lokal, set `BASE_URL=http://localhost:3000` di `.env` supaya link pembayaran simulasi mengarah ke lokal.

## Yang WAJIB diisi untuk verifikasi Atlantic-Pedia

1. Di `.env`, isi `ATLANTIC_USERNAME` dengan **username akun Atlantic-Pedia** Anda.
   File akan otomatis tersedia di `https://domainanda/atlantic.txt`.
2. Pastikan sudah ada produk (sudah ada 16 produk contoh dari seed).
3. Saat mengajukan H2H: **jangan aktifkan payment gateway** — biarkan `PAYMENT_PROVIDER=mock`.
4. **Jangan** deploy di Vercel / hosting gratis. Gunakan VPS (lihat di bawah).
5. Web harus tetap berjalan selama proses pengajuan (pakai PM2).

## Deploy ke VPS (contoh Ubuntu + PM2 + Nginx)

```bash
# di server
git clone <repo> premium2in && cd premium2in
npm install --production
cp .env.example .env && nano .env   # isi BASE_URL=https://premium2in.msr.my.id, ATLANTIC_USERNAME, dll
npm i -g pm2
pm2 start server.js --name premium2in
pm2 save && pm2 startup
```

Contoh blok Nginx (reverse proxy + domain):

```nginx
server {
  server_name premium2in.msr.my.id;
  location / { proxy_pass http://127.0.0.1:3000; proxy_set_header Host $host; proxy_set_header X-Forwarded-For $remote_addr; }
}
```

Lalu pasang SSL: `sudo certbot --nginx -d premium2in.msr.my.id`.

## Mengaktifkan H2H asli (setelah akun di-upgrade)

1. Set `H2H_PROVIDER=atlantic` dan isi `ATLANTIC_API_KEY` (+ `ATLANTIC_BASE_URL` jika beda).
2. Buka `config/h2h/atlantic.js`. Sesuaikan:
   - `PATH_TRANSAKSI`, `PATH_STATUS`, `PATH_PRICELIST` sesuai endpoint dokumentasi H2H Anda.
   - Nama field payload (`code`, `target`, `reff_id`, dst.) dan pemetaan field respons.
   Bagian ini sengaja dibuat mudah diedit karena tiap akun H2H bisa berbeda formatnya.
3. `code` produk (di admin / seed) harus sama dengan **kode layanan** milik Atlantic.

QiosPay / OrderKuota: isi kredensial di `.env`, lengkapi `config/h2h/qiospay.js` / `orderkuota.js`,
lalu set `H2H_PROVIDER=qiospay` atau `orderkuota`.

## Mengaktifkan Payment Gateway (untuk deposit)

Set `PAYMENT_PROVIDER` ke salah satu: `duitku` | `tripay` | `dompetx`, lalu isi kredensialnya di `.env`.
Callback URL yang dipakai: `https://domainanda/deposit/callback/<gateway>`.
Adapter tersedia di `config/payment/`. **Ingat: nonaktifkan (kembalikan ke `mock`) selama pengajuan H2H.**

## Struktur singkat

```
server.js              # entry
lib/                   # db (JSON), auth, order/deposit service, scheduler, seed
config/h2h/            # provider H2H (mock, atlantic, qiospay, orderkuota)
config/payment/        # gateway (mock, duitku, tripay, dompetx)
routes/                # auth, pages, actions (API), admin
views/                 # EJS (tema aurora)
public/                # css & js
data/db.json           # penyimpanan (dibuat otomatis)
```

## Catatan

- Penyimpanan memakai file JSON (`data/db.json`) agar tanpa dependensi native & mudah dipindah.
  Untuk skala besar, migrasikan ke MySQL/PostgreSQL.
- Ubah `SESSION_SECRET` dan password admin sebelum produksi.
- Kepatuhan legal atas produk yang dijual (mis. akun aplikasi premium) menjadi tanggung jawab penjual.
