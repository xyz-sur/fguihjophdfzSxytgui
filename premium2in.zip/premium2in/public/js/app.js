'use strict';
const rp = (n) => 'Rp' + Number(n || 0).toLocaleString('id-ID');
const $ = (id) => document.getElementById(id);

async function post(url, body) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
  return r.json();
}

// ---------- MODAL ----------
function modal({ type, title, text, actions }) {
  const icon = type === 'ok' ? '✓' : type === 'pend' ? '⏳' : '✕';
  const btns = (actions || [{ label: 'Tutup', close: true }])
    .map((a, i) => `<button class="btn ${a.ghost ? 'ghost' : ''}" data-i="${i}">${a.label}</button>`).join('');
  $('modal-root').innerHTML =
    `<div class="overlay" id="ov"><div class="modal">
      <div class="ic ${type}">${icon}</div><h3>${title}</h3><p>${text || ''}</p>
      <div style="display:flex;gap:10px;justify-content:center">${btns}</div>
    </div></div>`;
  const close = () => ($('modal-root').innerHTML = '');
  $('ov').addEventListener('click', (e) => { if (e.target.id === 'ov') close(); });
  (actions || [{ close: true }]).forEach((a, i) => {
    $('modal-root').querySelector(`[data-i="${i}"]`).addEventListener('click', () => {
      if (a.onClick) a.onClick();
      if (a.href) window.location.href = a.href;
      if (a.close !== false) close();
    });
  });
}

// ---------- PRODUCT: denom + buy ----------
(function product() {
  const denoms = $('denoms');
  if (!denoms) return;
  let current = { id: $('buyBtn')?.dataset.id, price: null };
  denoms.querySelectorAll('.denom').forEach((el) => {
    el.addEventListener('click', () => {
      denoms.querySelectorAll('.denom').forEach((x) => x.classList.remove('sel'));
      el.classList.add('sel');
      current.id = el.dataset.id;
      current.price = Number(el.dataset.price);
      const targetType = el.dataset.target;
      $('sumName').textContent = el.querySelector('.n').textContent;
      $('sumPrice').textContent = rp(current.price);
      if ($('buyBtn')) { $('buyBtn').dataset.id = current.id; $('buyPrice').textContent = rp(current.price); }
      if (window.__targetLabels && $('targetLabel')) $('targetLabel').textContent = window.__targetLabels[targetType] || 'Tujuan';
    });
  });

  const buyBtn = $('buyBtn');
  if (buyBtn) buyBtn.addEventListener('click', async () => {
    const target = $('target').value.trim();
    if (!target) return modal({ type: 'bad', title: 'Tujuan kosong', text: 'Isi nomor/ID tujuan dulu.' });
    buyBtn.disabled = true; buyBtn.textContent = 'Memproses…';
    const d = await post('/api/order', { productId: buyBtn.dataset.id, target });
    buyBtn.disabled = false; buyBtn.innerHTML = 'Beli — <span id="buyPrice">' + rp(current.price || 0) + '</span>';
    if (d.ok) {
      modal({ type: d.order.status === 'pending' ? 'pend' : 'ok',
        title: d.order.status === 'pending' ? 'Sedang diproses' : 'Transaksi berhasil',
        text: `${d.order.productName} ke ${d.order.target}.` + (d.order.sn ? ` SN: ${d.order.sn}` : ''),
        actions: [{ label: 'Lihat transaksi', href: '/orders' }, { label: 'Tutup', ghost: true }] });
    } else {
      modal({ type: 'bad', title: 'Gagal', text: d.message + (d.refunded ? ' (saldo dikembalikan)' : ''),
        actions: d.message && d.message.includes('Saldo') ? [{ label: 'Deposit', href: '/deposit' }, { label: 'Tutup', ghost: true }] : null });
    }
  });
})();

// ---------- DEPOSIT ----------
(function deposit() {
  const btn = $('depositBtn');
  if (!btn) return;
  document.querySelectorAll('.nom').forEach((el) => el.addEventListener('click', () => {
    document.querySelectorAll('.nom').forEach((x) => x.classList.remove('sel'));
    el.classList.add('sel'); $('amount').value = el.dataset.v;
  }));
  btn.addEventListener('click', async () => {
    const amount = Number($('amount').value);
    if (!amount || amount < 10000) return modal({ type: 'bad', title: 'Nominal kurang', text: 'Minimal Rp10.000.' });
    btn.disabled = true; btn.textContent = 'Membuat…';
    const d = await post('/api/deposit', { amount });
    btn.disabled = false; btn.textContent = 'Buat Pembayaran';
    if (d.ok && d.payUrl) window.location.href = d.payUrl;
    else modal({ type: 'bad', title: 'Gagal', text: d.message || 'Tidak bisa membuat pembayaran.' });
  });
})();

// ---------- SCHEDULE ----------
(function schedule() {
  const freq = $('s_freq');
  if (!freq) return;
  const sync = () => {
    $('wrap_dow').style.display = freq.value === 'weekly' ? '' : 'none';
    $('wrap_dom').style.display = freq.value === 'monthly' ? '' : 'none';
  };
  freq.addEventListener('change', sync); sync();

  const prod = $('s_product');
  prod.addEventListener('change', () => {
    const t = prod.selectedOptions[0].dataset.target;
    $('s_target').placeholder = t === 'account' ? 'email@contoh.com' : t === 'meter' ? 'ID pelanggan' : '0812xxxxxxxx';
  });

  $('s_create').addEventListener('click', async () => {
    const body = {
      productId: prod.value, target: $('s_target').value.trim(),
      frequency: freq.value, time: $('s_time').value,
      dayOfWeek: $('s_dow').value, dayOfMonth: $('s_dom').value,
    };
    if (!body.target) return modal({ type: 'bad', title: 'Tujuan kosong', text: 'Isi nomor tujuan dulu.' });
    const d = await post('/api/schedule', body);
    if (d.ok) modal({ type: 'ok', title: 'Jadwal dibuat', text: 'Pembelian otomatis akan berjalan sesuai jadwal.', actions: [{ label: 'Oke', onClick: () => location.reload() }] });
    else modal({ type: 'bad', title: 'Gagal', text: d.message });
  });
})();

async function toggleSch(id) { await post('/api/schedule/' + id + '/toggle'); location.reload(); }
async function delSch(id) { if (confirm('Hapus jadwal ini?')) { await post('/api/schedule/' + id + '/delete'); location.reload(); } }

// ---------- ADMIN ----------
async function addProd() {
  const body = {
    category: $('p_cat').value, catLabel: $('p_catlabel').value, code: $('p_code').value,
    name: $('p_name').value, price: $('p_price').value, targetType: $('p_type').value,
  };
  const d = await post('/admin/products', body);
  if (d.ok) location.reload(); else alert(d.message || 'Gagal');
}
async function toggleProd(id) { await post('/admin/products/' + id + '/toggle'); location.reload(); }
