'use strict';
const axios = require('axios');
// Placeholder adapter OrderKuota H2H. Lengkapi endpoint/param sesuai dokumentasi OrderKuota Anda.
async function topup({ productCode, target, refId }, cfg) {
  const base = cfg.ORDERKUOTA_BASE_URL;
  if (!base || !cfg.ORDERKUOTA_API_KEY) {
    await new Promise((r) => setTimeout(r, 400));
    return { success: true, status: 'success', sn: 'OKSIM' + Date.now().toString().slice(-8),
      message: `[SIMULASI OrderKuota] ${productCode} -> ${target}. Lengkapi kredensial OrderKuota.`, provider: 'orderkuota' };
  }
  try {
    // >>> sesuaikan dengan dokumentasi OrderKuota <<<
    const res = await axios.post(base, {
      memberID: cfg.ORDERKUOTA_MEMBER_ID, product: productCode, dest: target,
      refID: refId, apikey: cfg.ORDERKUOTA_API_KEY,
    }, { timeout: 30000 });
    const d = res.data || {};
    const ok = /sukses|success/i.test(JSON.stringify(d));
    return { success: ok, status: ok ? 'success' : 'pending', sn: d.sn || null, message: d.message || '', provider: 'orderkuota', raw: d };
  } catch (err) {
    return { success: false, status: 'failed', provider: 'orderkuota', message: err.message };
  }
}
module.exports = { name: 'orderkuota', topup };
