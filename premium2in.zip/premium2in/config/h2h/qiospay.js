'use strict';
const axios = require('axios');
// Placeholder adapter QiosPay H2H. Lengkapi endpoint/param sesuai dokumentasi QiosPay Anda.
async function topup({ productCode, target, refId }, cfg) {
  const base = cfg.QIOSPAY_BASE_URL;
  if (!base || !cfg.QIOSPAY_API_KEY) {
    await new Promise((r) => setTimeout(r, 400));
    return { success: true, status: 'success', sn: 'QSIM' + Date.now().toString().slice(-8),
      message: `[SIMULASI QiosPay] ${productCode} -> ${target}. Lengkapi kredensial QiosPay.`, provider: 'qiospay' };
  }
  try {
    // >>> sesuaikan dengan dokumentasi QiosPay <<<
    const res = await axios.post(base, {
      memberID: cfg.QIOSPAY_MEMBER_ID, product: productCode, dest: target,
      refID: refId, pin: cfg.QIOSPAY_PIN, password: cfg.QIOSPAY_API_KEY,
    }, { timeout: 30000 });
    const d = res.data || {};
    const ok = /sukses|success/i.test(JSON.stringify(d));
    return { success: ok, status: ok ? 'success' : 'pending', sn: d.sn || null, message: d.message || '', provider: 'qiospay', raw: d };
  } catch (err) {
    return { success: false, status: 'failed', provider: 'qiospay', message: err.message };
  }
}
module.exports = { name: 'qiospay', topup };
