'use strict';

const atlantic = require('./atlantic');
const qiospay = require('./qiospay');
const orderkuota = require('./orderkuota');

// Provider "mock": selalu sukses, untuk demo & verifikasi tanpa saldo H2H.
const mock = {
  name: 'mock',
  async topup({ productCode, target, refId }) {
    await new Promise((r) => setTimeout(r, 400));
    return {
      success: true,
      status: 'success',
      sn: 'SN' + Date.now().toString().slice(-10),
      message: `Berhasil (simulasi) ${productCode} ke ${target}`,
      provider: 'mock',
    };
  },
  async checkStatus() {
    return { success: true, status: 'success', provider: 'mock' };
  },
};

const REGISTRY = { mock, atlantic, qiospay, orderkuota };

function active(cfg) {
  const name = (cfg.H2H_PROVIDER || 'mock').toLowerCase();
  return REGISTRY[name] || mock;
}

module.exports = { active, REGISTRY };
