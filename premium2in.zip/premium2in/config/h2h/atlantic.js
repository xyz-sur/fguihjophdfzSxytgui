'use strict';

const axios = require('axios');

/**
 * Adapter Atlantic-Pedia H2H.
 *
 * PENTING: format endpoint & parameter di bawah adalah STRUKTUR umum.
 * Setelah akun Anda di-upgrade ke H2H, buka dokumentasi H2H Anda lalu
 * sesuaikan PATH_* dan nama field payload di bawah ini agar 100% cocok.
 *
 * Selama ATLANTIC_API_KEY kosong, adapter otomatis jatuh ke mode simulasi
 * supaya web tetap berjalan (dibutuhkan saat pengajuan verifikasi H2H).
 */

const PATH_TRANSAKSI = '/transaksi'; // sesuaikan
const PATH_STATUS = '/transaksi/status'; // sesuaikan
const PATH_PRICELIST = '/layanan'; // sesuaikan

function baseCfg(cfg) {
  return {
    base: (cfg.ATLANTIC_BASE_URL || 'https://atlantic-pedia.co.id/api').replace(/\/$/, ''),
    apiKey: cfg.ATLANTIC_API_KEY || '',
  };
}

async function topup({ productCode, target, refId }, cfg) {
  const { base, apiKey } = baseCfg(cfg);

  // Fallback simulasi bila belum ada API key H2H.
  if (!apiKey) {
    await new Promise((r) => setTimeout(r, 400));
    return {
      success: true,
      status: 'success',
      sn: 'SIM' + Date.now().toString().slice(-10),
      message: `[SIMULASI Atlantic] ${productCode} -> ${target}. Isi ATLANTIC_API_KEY untuk transaksi asli.`,
      provider: 'atlantic',
    };
  }

  try {
    const res = await axios.post(
      base + PATH_TRANSAKSI,
      {
        // >>> sesuaikan nama field dengan dokumentasi H2H Anda <<<
        api_key: apiKey,
        code: productCode,
        target,
        reff_id: refId,
      },
      { timeout: 30000, headers: { 'Content-Type': 'application/json' } }
    );
    const d = res.data || {};
    // >>> sesuaikan pemetaan field respons <<<
    const status = String(d?.data?.status || d?.status || '').toLowerCase();
    const ok = status === 'success' || status === 'sukses' || d?.success === true;
    return {
      success: ok,
      status: ok ? 'success' : (status === 'pending' ? 'pending' : 'failed'),
      sn: d?.data?.sn || d?.sn || null,
      message: d?.data?.message || d?.message || (ok ? 'Berhasil' : 'Gagal'),
      provider: 'atlantic',
      raw: d,
    };
  } catch (err) {
    return { success: false, status: 'failed', provider: 'atlantic', message: httpErr(err) };
  }
}

async function checkStatus({ refId }, cfg) {
  const { base, apiKey } = baseCfg(cfg);
  if (!apiKey) return { success: true, status: 'success', provider: 'atlantic' };
  try {
    const res = await axios.post(base + PATH_STATUS, { api_key: apiKey, reff_id: refId }, { timeout: 20000 });
    const d = res.data || {};
    const status = String(d?.data?.status || d?.status || '').toLowerCase();
    return { success: true, status: status || 'pending', provider: 'atlantic', raw: d };
  } catch (err) {
    return { success: false, status: 'unknown', provider: 'atlantic', message: httpErr(err) };
  }
}

async function priceList(cfg) {
  const { base, apiKey } = baseCfg(cfg);
  if (!apiKey) return { success: false, message: 'ATLANTIC_API_KEY kosong', products: [] };
  try {
    const res = await axios.post(base + PATH_PRICELIST, { api_key: apiKey }, { timeout: 20000 });
    return { success: true, products: res.data?.data || res.data || [], raw: res.data };
  } catch (err) {
    return { success: false, message: httpErr(err), products: [] };
  }
}

function httpErr(err) {
  if (err.response) return `HTTP ${err.response.status}: ${JSON.stringify(err.response.data).slice(0, 200)}`;
  if (err.code === 'ECONNABORTED') return 'Timeout menghubungi Atlantic';
  return err.message || 'Gagal menghubungi Atlantic';
}

module.exports = { name: 'atlantic', topup, checkStatus, priceList };
