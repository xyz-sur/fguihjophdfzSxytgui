'use strict';

const duitku = require('./duitku');
const tripay = require('./tripay');
const dompetx = require('./dompetx');

// Mock: buat "invoice" lokal, pembayaran disimulasikan lewat halaman /deposit/simulate.
const mock = {
  name: 'mock',
  async createDeposit({ amount, refId, baseUrl }) {
    return {
      success: true,
      provider: 'mock',
      providerRef: 'MOCK-' + refId,
      payUrl: `${baseUrl}/deposit/simulate/${refId}`,
      message: 'Invoice simulasi dibuat. Klik untuk menandai lunas.',
    };
  },
};

const REGISTRY = { mock, duitku, tripay, dompetx };

function active(cfg) {
  const name = (cfg.PAYMENT_PROVIDER || 'mock').toLowerCase();
  return REGISTRY[name] || mock;
}

module.exports = { active, REGISTRY };
