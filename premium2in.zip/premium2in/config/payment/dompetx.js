'use strict';

const axios = require('axios');
const crypto = require('crypto');

/**
 * DompetX — payment gateway (untuk deposit saldo).
 * Signature sesuai dokumentasi resmi: HMAC-SHA256 atas `timestamp + '.' + body`
 * memakai API key, dikirim di header X-DOMPAY-*.
 */
async function createDeposit({ amount, refId, baseUrl }, cfg) {
  const base = (cfg.DOMPETX_BASE_URL || 'https://api.dompetx.com').replace(/\/$/, '');
  const apiKey = cfg.DOMPETX_API_KEY;
  if (!apiKey) {
    return { success: false, provider: 'dompetx', message: 'DOMPETX_API_KEY belum diisi di .env' };
  }

  const timestamp = Math.floor(Date.now() / 1000);
  const bodyObj = {
    method: 'QRIS',
    amount: Number(amount),
    currency: 'IDR',
    reference: refId,
    callback_url: `${baseUrl}/deposit/callback/dompetx`,
  };
  const body = JSON.stringify(bodyObj);
  const signature = crypto.createHmac('sha256', apiKey).update(`${timestamp}.${body}`).digest('hex');

  try {
    const res = await axios.post(base + '/v1/payments', body, {
      timeout: 20000,
      headers: {
        'Content-Type': 'application/json',
        'X-DOMPAY-API-Key': apiKey,
        'X-DOMPAY-Signature': signature,
        'X-DOMPAY-Timestamp': String(timestamp),
        'Idempotency-Key': 'dep_' + refId,
      },
    });
    const d = res.data || {};
    const payUrl = d?.data?.payment_url || d?.data?.checkout_url || d?.payment_url || null;
    return {
      success: true,
      provider: 'dompetx',
      providerRef: d?.data?.id || d?.id || refId,
      payUrl,
      raw: d,
      message: 'Transaksi DompetX dibuat',
    };
  } catch (err) {
    return { success: false, provider: 'dompetx', message: httpErr(err) };
  }
}

function httpErr(err) {
  if (err.response) return `HTTP ${err.response.status}: ${JSON.stringify(err.response.data).slice(0, 200)}`;
  return err.message || 'Gagal menghubungi DompetX';
}

module.exports = { name: 'dompetx', createDeposit };
