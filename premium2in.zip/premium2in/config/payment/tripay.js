'use strict';
const axios = require('axios');
const crypto = require('crypto');
/**
 * Tripay — payment gateway. Signature = HMAC-SHA256(merchant_code + merchant_ref + amount, private_key).
 */
async function createDeposit({ amount, refId, baseUrl, customer }, cfg) {
  const sandbox = (cfg.TRIPAY_MODE || 'sandbox') !== 'production';
  const base = sandbox ? 'https://tripay.co.id/api-sandbox' : 'https://tripay.co.id/api';
  const { TRIPAY_API_KEY: apiKey, TRIPAY_PRIVATE_KEY: privateKey, TRIPAY_MERCHANT_CODE: merchant } = cfg;
  if (!apiKey || !privateKey || !merchant) {
    return { success: false, provider: 'tripay', message: 'Kredensial Tripay (API_KEY/PRIVATE_KEY/MERCHANT_CODE) belum lengkap' };
  }
  const amt = Number(amount);
  const signature = crypto.createHmac('sha256', privateKey).update(merchant + refId + amt).digest('hex');
  try {
    const res = await axios.post(base + '/transaction/create', {
      method: 'QRIS', merchant_ref: refId, amount: amt,
      customer_name: customer?.name || 'Member', customer_email: customer?.email || 'member@premium2in.local',
      order_items: [{ name: 'Deposit Saldo', price: amt, quantity: 1 }],
      callback_url: `${baseUrl}/deposit/callback/tripay`,
      return_url: `${baseUrl}/dashboard`,
      signature,
    }, { timeout: 20000, headers: { Authorization: 'Bearer ' + apiKey } });
    const d = res.data?.data || {};
    return { success: true, provider: 'tripay', providerRef: d.reference || refId, payUrl: d.checkout_url || null, raw: res.data };
  } catch (err) {
    const msg = err.response ? `HTTP ${err.response.status}: ${JSON.stringify(err.response.data).slice(0,200)}` : err.message;
    return { success: false, provider: 'tripay', message: msg };
  }
}
module.exports = { name: 'tripay', createDeposit };
