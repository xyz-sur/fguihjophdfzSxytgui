'use strict';
const axios = require('axios');
const crypto = require('crypto');
/**
 * Duitku (POP createInvoice). Signature = SHA256(merchantCode + timestamp(ms) + apiKey).
 */
async function createDeposit({ amount, refId, baseUrl, customer }, cfg) {
  const sandbox = (cfg.DUITKU_MODE || 'sandbox') !== 'production';
  const base = sandbox ? 'https://sandbox.duitku.com' : 'https://passport.duitku.com';
  const merchant = cfg.DUITKU_MERCHANT_CODE, apiKey = cfg.DUITKU_API_KEY;
  if (!merchant || !apiKey) {
    return { success: false, provider: 'duitku', message: 'Kredensial Duitku (MERCHANT_CODE/API_KEY) belum lengkap' };
  }
  const timestamp = Date.now();
  const signature = crypto.createHash('sha256').update(merchant + timestamp + apiKey).digest('hex');
  try {
    const res = await axios.post(base + '/webapi/api/merchant/createInvoice', {
      paymentAmount: Number(amount), merchantOrderId: refId, productDetails: 'Deposit Saldo premium2in',
      email: customer?.email || 'member@premium2in.local', customerVaName: customer?.name || 'Member',
      callbackUrl: `${baseUrl}/deposit/callback/duitku`, returnUrl: `${baseUrl}/dashboard`,
    }, { timeout: 20000, headers: {
      'Content-Type': 'application/json', 'x-duitku-signature': signature,
      'x-duitku-timestamp': String(timestamp), 'x-duitku-merchantcode': merchant,
    }});
    const d = res.data || {};
    return { success: true, provider: 'duitku', providerRef: d.reference || refId, payUrl: d.paymentUrl || null, raw: d };
  } catch (err) {
    const msg = err.response ? `HTTP ${err.response.status}: ${JSON.stringify(err.response.data).slice(0,200)}` : err.message;
    return { success: false, provider: 'duitku', message: msg };
  }
}
module.exports = { name: 'duitku', createDeposit };
