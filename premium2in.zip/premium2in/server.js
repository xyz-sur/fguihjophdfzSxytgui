'use strict';

require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');

const db = require('./lib/db');
const { seed } = require('./lib/seed');
const { currentUser } = require('./lib/auth');
const { rupiah } = require('./lib/util');
const scheduler = require('./lib/scheduler');

const app = express();
const PORT = process.env.PORT || 3000;

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/assets', express.static(path.join(__dirname, 'public')));
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'premium2in-dev-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000 },
  })
);

// Locals untuk semua view
app.use((req, res, next) => {
  res.locals.SITE_NAME = process.env.SITE_NAME || 'premium2in';
  res.locals.SITE_TAGLINE = process.env.SITE_TAGLINE || '';
  res.locals.rupiah = rupiah;
  res.locals.me = currentUser(req);
  res.locals.path = req.path;
  next();
});

// ===== File verifikasi H2H Atlantic-Pedia =====
// Atlantic mensyaratkan file atlantic.txt berisi username Anda, dapat diakses publik.
app.get('/atlantic.txt', (req, res) => {
  res.type('text/plain').send((process.env.ATLANTIC_USERNAME || 'isi-username-atlantic-anda') + '\n');
});

// Routes
app.use('/', require('./routes/auth'));
app.use('/', require('./routes/pages'));
app.use('/api', require('./routes/actions'));
app.use('/admin', require('./routes/admin'));

app.get('/health', (req, res) => res.json({
  ok: true,
  h2h: process.env.H2H_PROVIDER || 'mock',
  payment: process.env.PAYMENT_PROVIDER || 'mock',
}));

// 404
app.use((req, res) => res.status(404).render('404'));

// Inisialisasi
seed(process.env);
scheduler.start(process.env);

app.listen(PORT, () => {
  console.log(`\n  ${process.env.SITE_NAME || 'premium2in'} berjalan di http://localhost:${PORT}`);
  console.log(`  H2H: ${process.env.H2H_PROVIDER || 'mock'}  |  Payment: ${process.env.PAYMENT_PROVIDER || 'mock'}`);
  console.log(`  atlantic.txt -> username: ${process.env.ATLANTIC_USERNAME || '(belum diisi)'}\n`);
});
