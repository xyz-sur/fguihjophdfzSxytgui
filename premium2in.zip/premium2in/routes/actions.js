'use strict';

const express = require('express');
const router = express.Router();
const db = require('../lib/db');
const { requireLogin } = require('../lib/auth');
const { createOrder } = require('../lib/orderService');
const { createDeposit } = require('../lib/depositService');

// ===== ORDER / TOPUP =====
router.post('/order', requireLogin, async (req, res) => {
  const { productId, target } = req.body;
  if (!target || !String(target).trim()) {
    return res.status(400).json({ ok: false, message: 'Nomor/ID tujuan wajib diisi' });
  }
  const result = await createOrder(req.user, { productId, target: String(target).trim(), source: 'manual' }, process.env);
  res.json(result);
});

// ===== DEPOSIT =====
router.post('/deposit', requireLogin, async (req, res) => {
  const amount = Number(req.body.amount);
  const result = await createDeposit(req.user, amount, process.env);
  if (!result.ok) return res.status(400).json(result);
  res.json(result);
});

// ===== SCHEDULE (pembelian terjadwal) =====
router.post('/schedule', requireLogin, (req, res) => {
  const { productId, target, frequency, time, dayOfWeek, dayOfMonth } = req.body;
  const product = db.find('products', (p) => p.id === productId && p.active);
  if (!product) return res.status(400).json({ ok: false, message: 'Produk tidak valid' });
  if (!target) return res.status(400).json({ ok: false, message: 'Nomor tujuan wajib diisi' });
  if (!['daily', 'weekly', 'monthly'].includes(frequency)) {
    return res.status(400).json({ ok: false, message: 'Frekuensi tidak valid' });
  }
  const schedule = db.insert('schedules', {
    id: db.id('SCH-'),
    userId: req.user.id,
    productId,
    productName: product.name,
    target: String(target).trim(),
    frequency,
    time: time || '08:00',
    dayOfWeek: frequency === 'weekly' ? Number(dayOfWeek || 1) : null,
    dayOfMonth: frequency === 'monthly' ? Number(dayOfMonth || 1) : null,
    active: true,
    runCount: 0,
    createdAt: new Date().toISOString(),
  });
  res.json({ ok: true, schedule });
});

router.post('/schedule/:id/toggle', requireLogin, (req, res) => {
  const s = db.find('schedules', (x) => x.id === req.params.id && x.userId === req.user.id);
  if (!s) return res.status(404).json({ ok: false });
  db.update('schedules', (x) => x.id === s.id, { active: !s.active });
  res.json({ ok: true, active: !s.active });
});

router.post('/schedule/:id/delete', requireLogin, (req, res) => {
  db.remove('schedules', (x) => x.id === req.params.id && x.userId === req.user.id);
  res.json({ ok: true });
});

module.exports = router;
