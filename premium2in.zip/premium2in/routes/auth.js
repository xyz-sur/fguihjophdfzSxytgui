'use strict';

const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const db = require('../lib/db');
const { normalizeUsername, isValidContact } = require('../lib/util');

router.get('/register', (req, res) => {
  if (req.session.uid) return res.redirect('/dashboard');
  res.render('register', { error: null, form: {} });
});

router.post('/register', (req, res) => {
  const { contact, name, password, password2 } = req.body;
  const form = { contact, name };
  if (!isValidContact(contact)) {
    return res.render('register', { error: 'Masukkan nomor WhatsApp (mis. 0812...) atau username Telegram (mis. @namamu).', form });
  }
  if (!password || password.length < 6) {
    return res.render('register', { error: 'Password minimal 6 karakter.', form });
  }
  if (password !== password2) {
    return res.render('register', { error: 'Konfirmasi password tidak sama.', form });
  }
  const username = normalizeUsername(contact);
  if (db.find('users', (u) => u.username === username)) {
    return res.render('register', { error: 'Nomor/username ini sudah terdaftar. Silakan login.', form });
  }
  const user = db.insert('users', {
    id: db.id('U-'),
    username,
    name: (name || '').trim() || username,
    contactType: contact.trim().startsWith('@') ? 'telegram' : 'whatsapp',
    role: 'member',
    saldo: 0,
    passwordHash: bcrypt.hashSync(password, 10),
    createdAt: new Date().toISOString(),
  });
  req.session.uid = user.id;
  res.redirect('/dashboard');
});

router.get('/login', (req, res) => {
  if (req.session.uid) return res.redirect('/dashboard');
  res.render('login', { error: null, form: {} });
});

router.post('/login', (req, res) => {
  const { contact, password } = req.body;
  const raw = String(contact || '').trim();
  const username = normalizeUsername(contact);
  const user = db.find('users', (u) => u.username === username || u.username === raw || u.username === raw.toLowerCase());
  if (!user || !bcrypt.compareSync(password || '', user.passwordHash)) {
    return res.render('login', { error: 'Nomor/username atau password salah.', form: { contact } });
  }
  req.session.uid = user.id;
  res.redirect(user.role === 'admin' ? '/admin' : '/dashboard');
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});
router.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

module.exports = router;
