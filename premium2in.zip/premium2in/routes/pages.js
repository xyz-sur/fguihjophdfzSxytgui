'use strict';

const express = require('express');
const router = express.Router();
const db = require('../lib/db');
const { requireLogin } = require('../lib/auth');
const { markPaid } = require('../lib/depositService');

// Kategori untuk navigasi toko
function categories() {
  const map = new Map();
  for (const p of db.filter('products', (x) => x.active)) {
    if (!map.has(p.category)) map.set(p.category, { key: p.category, label: p.catLabel, count: 0 });
    map.get(p.category).count += 1;
  }
  return [...map.values()];
}

// Beranda
router.get('/', (req, res) => {
  res.render('home', { cats: categories(), featured: db.filter('products', (p) => p.active).slice(0, 8) });
});

// Toko (semua produk / per kategori)
router.get('/store', (req, res) => {
  const cat = req.query.cat;
  let products = db.filter('products', (p) => p.active);
  if (cat) products = products.filter((p) => p.category === cat);
  res.render('store', { cats: categories(), products, activeCat: cat || null });
});

// Detail produk & form order
router.get('/product/:id', (req, res) => {
  const product = db.find('products', (p) => p.id === req.params.id && p.active);
  if (!product) return res.status(404).send('Produk tidak ditemukan');
  // produk lain dalam kategori sama sebagai pilihan denom
  const siblings = db.filter('products', (p) => p.category === product.category && p.active);
  res.render('product', { cats: categories(), product, siblings });
});

// Dashboard member
router.get('/dashboard', requireLogin, (req, res) => {
  const orders = db.filter('orders', (o) => o.userId === req.user.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 10);
  const deposits = db.filter('deposits', (d) => d.userId === req.user.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5);
  res.render('dashboard', { user: req.user, orders, deposits });
});

// Riwayat transaksi
router.get('/orders', requireLogin, (req, res) => {
  const orders = db.filter('orders', (o) => o.userId === req.user.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  res.render('orders', { user: req.user, orders });
});

// Halaman deposit
router.get('/deposit', requireLogin, (req, res) => {
  res.render('deposit', { user: req.user, provider: process.env.PAYMENT_PROVIDER || 'mock', done: req.query.done });
});

// Halaman jadwal
router.get('/schedule', requireLogin, (req, res) => {
  const schedules = db.filter('schedules', (s) => s.userId === req.user.id);
  const products = db.filter('products', (p) => p.active);
  res.render('schedule', { user: req.user, schedules, products });
});

// Simulasi pembayaran (mode mock): tandai lunas lalu kembali ke deposit
router.get('/deposit/simulate/:refId', requireLogin, (req, res) => {
  const dep = db.find('deposits', (d) => d.id === req.params.refId && d.userId === req.user.id);
  if (!dep) return res.status(404).send('Deposit tidak ditemukan');
  markPaid(dep.id);
  res.redirect('/deposit?done=1');
});

// Callback gateway asli (Tripay/Duitku/DompetX) — verifikasi minimal berdasar reference
router.post('/deposit/callback/:gw', (req, res) => {
  const b = req.body || {};
  const ref = b.merchant_ref || b.merchantOrderId || b.reference || (b.data && b.data.reference);
  const status = String(b.status || b.resultCode || (b.data && b.data.status) || '').toLowerCase();
  const paid = ['paid', 'success', 'settlement', '00', 'sukses'].some((s) => status.includes(s));
  if (ref && paid) markPaid(ref);
  res.json({ success: true });
});

module.exports = router;
