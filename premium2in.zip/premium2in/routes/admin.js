'use strict';

const express = require('express');
const router = express.Router();
const db = require('../lib/db');
const { requireAdmin } = require('../lib/auth');

router.use(requireAdmin);

router.get('/', (req, res) => {
  const users = db.all('users');
  const orders = db.all('orders').sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const products = db.all('products');
  const revenue = orders.filter((o) => o.status === 'success').reduce((s, o) => s + o.price, 0);
  res.render('admin/index', {
    user: req.user,
    stats: {
      members: users.filter((u) => u.role === 'member').length,
      orders: orders.length,
      success: orders.filter((o) => o.status === 'success').length,
      revenue,
    },
    recentOrders: orders.slice(0, 15),
    products,
  });
});

router.get('/users', (req, res) => {
  res.render('admin/users', { user: req.user, users: db.all('users') });
});

router.post('/users/:id/saldo', (req, res) => {
  const amount = Number(req.body.amount);
  const u = db.find('users', (x) => x.id === req.params.id);
  if (!u) return res.status(404).json({ ok: false });
  db.update('users', (x) => x.id === u.id, { saldo: Math.max(0, u.saldo + amount) });
  res.json({ ok: true, saldo: db.find('users', (x) => x.id === u.id).saldo });
});

router.post('/products', (req, res) => {
  const { category, catLabel, code, name, price, targetType } = req.body;
  if (!code || !name || !price) return res.status(400).json({ ok: false, message: 'Lengkapi data produk' });
  const p = db.insert('products', {
    id: db.id('P-'),
    category: category || 'lain',
    catLabel: catLabel || 'Lainnya',
    code, name,
    price: Number(price),
    targetType: targetType || 'phone',
    active: true,
    createdAt: new Date().toISOString(),
  });
  res.json({ ok: true, product: p });
});

router.post('/products/:id/toggle', (req, res) => {
  const p = db.find('products', (x) => x.id === req.params.id);
  if (!p) return res.status(404).json({ ok: false });
  db.update('products', (x) => x.id === p.id, { active: !p.active });
  res.json({ ok: true, active: !p.active });
});

module.exports = router;
