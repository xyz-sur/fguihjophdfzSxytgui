require('dotenv').config();
const path = require('path');
const express = require('express');
const duitku = require('./lib/duitku');
const store = require('./lib/store');

const app = express();
const PORT = process.env.PORT || 3000;
const APP_BASE_URL = (process.env.APP_BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');

app.use(express.json());
app.use(express.urlencoded({ extended: true })); // callback Duitku: x-www-form-urlencoded
app.use(express.static(path.join(__dirname, 'public')));

/* ---------- API untuk frontend ---------- */

// Daftar metode pembayaran aktif
app.get('/api/payment-methods', async (req, res) => {
  try {
    const amount = parseInt(req.query.amount || '10000', 10);
    const data = await duitku.getPaymentMethods(amount);
    res.json(data);
  } catch (err) {
    console.error('[payment-methods]', err.message);
    res.status(502).json({ error: err.message });
  }
});

// Buat transaksi baru
app.post('/api/create-transaction', async (req, res) => {
  try {
    const { name, email, phone, amount, paymentMethod, product } = req.body;

    if (!name || !email || !amount || !paymentMethod) {
      return res.status(400).json({ error: 'Nama, email, nominal, dan metode pembayaran wajib diisi.' });
    }
    const paymentAmount = parseInt(amount, 10);
    if (!Number.isInteger(paymentAmount) || paymentAmount < 10000) {
      return res.status(400).json({ error: 'Nominal minimal Rp 10.000.' });
    }

    const merchantOrderId = `INV-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const productDetails = product || `Top Up Saldo - ${name}`;

    const result = await duitku.createTransaction({
      merchantOrderId,
      paymentAmount,
      paymentMethod,
      productDetails,
      customerName: name,
      email,
      phoneNumber: phone,
      callbackUrl: `${APP_BASE_URL}/callback`,
      returnUrl: `${APP_BASE_URL}/return`,
      expiryPeriod: 60,
    });

    store.save(merchantOrderId, {
      merchantOrderId,
      reference: result.reference,
      amount: paymentAmount,
      paymentMethod,
      productDetails,
      customer: { name, email, phone },
      status: 'PENDING',
      statusCode: '01',
      paymentUrl: result.paymentUrl,
      vaNumber: result.vaNumber || null,
      qrString: result.qrString || null,
      createdAt: new Date().toISOString(),
    });

    res.json({
      merchantOrderId,
      reference: result.reference,
      paymentUrl: result.paymentUrl,
      vaNumber: result.vaNumber || null,
      amount: result.amount,
      statusCode: result.statusCode,
      statusMessage: result.statusMessage,
    });
  } catch (err) {
    console.error('[create-transaction]', err.message);
    res.status(502).json({ error: err.message });
  }
});

// Cek status ke server Duitku (sumber kebenaran) + update penyimpanan lokal
app.get('/api/status/:orderId', async (req, res) => {
  try {
    const { orderId } = req.params;
    const local = store.get(orderId);
    const remote = await duitku.checkTransaction(orderId);

    const statusMap = { '00': 'SUCCESS', '01': 'PENDING', '02': 'CANCELED' };
    if (local) {
      store.save(orderId, {
        status: statusMap[remote.statusCode] || remote.statusMessage,
        statusCode: remote.statusCode,
        fee: remote.fee,
      });
    }
    res.json({ local: store.get(orderId), duitku: remote });
  } catch (err) {
    console.error('[status]', err.message);
    res.status(502).json({ error: err.message });
  }
});

// Riwayat transaksi (untuk halaman monitor)
app.get('/api/transactions', (req, res) => {
  res.json(store.list());
});

/* ---------- Callback dari server Duitku ---------- */
// POST x-www-form-urlencoded, wajib balas HTTP 200 jika sukses diproses
app.post('/callback', async (req, res) => {
  const { merchantCode, amount, merchantOrderId, resultCode, reference, signature } = req.body;
  console.log('[callback] diterima:', JSON.stringify(req.body));

  const valid = duitku.verifyCallbackSignature({ merchantCode, amount, merchantOrderId, signature });
  if (!valid) {
    console.warn('[callback] BAD SIGNATURE untuk order', merchantOrderId);
    return res.status(400).send('Bad Signature');
  }

  // Signature valid -> update status lokal
  const status = resultCode === '00' ? 'SUCCESS' : 'FAILED';
  store.save(merchantOrderId, {
    merchantOrderId,
    reference,
    status,
    statusCode: resultCode,
    callbackReceivedAt: new Date().toISOString(),
    callbackPayload: req.body,
  });

  // Wajib segera balas 200 agar Duitku tidak menganggap callback gagal / mengirim ulang
  res.status(200).send('OK');

  // Praktik terbaik: verifikasi ulang ke API cek transaksi (di background)
  duitku
    .checkTransaction(merchantOrderId)
    .then((check) => {
      const statusMap = { '00': 'SUCCESS', '01': 'PENDING', '02': 'CANCELED' };
      store.save(merchantOrderId, {
        status: statusMap[check.statusCode] || check.statusMessage,
        statusCode: check.statusCode,
        fee: check.fee,
      });
      console.log(`[callback] order ${merchantOrderId} terverifikasi: ${check.statusMessage}`);
    })
    .catch((err) => console.warn('[callback] gagal cek ulang status:', err.message));
});

/* ---------- Redirect / return dari halaman pembayaran ---------- */
app.get('/return', (req, res) => {
  // Jangan pakai resultCode di URL untuk update status (bisa dimanipulasi user).
  res.sendFile(path.join(__dirname, 'public', 'return.html'));
});

app.listen(PORT, () => {
  console.log('--------------------------------------------------');
  console.log(`  Duitku Verify berjalan di http://localhost:${PORT}`);
  console.log(`  Environment Duitku : ${duitku.ENV} (${duitku.BASE_URL})`);
  console.log(`  Merchant Code      : ${duitku.MERCHANT_CODE || '(belum diisi!)'}`);
  console.log(`  Callback URL       : ${APP_BASE_URL}/callback`);
  console.log('--------------------------------------------------');
});
