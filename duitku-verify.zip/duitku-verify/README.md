# TopUpKu — Demo Web Pembayaran Duitku (Node.js)

Web sederhana untuk keperluan **verifikasi integrasi merchant Duitku**. Fitur:

- Ambil daftar metode pembayaran aktif (Get Payment Method)
- Buat transaksi via API v2 (`/webapi/api/merchant/v2/inquiry`)
- Terima **callback** dari server Duitku dengan verifikasi signature **HMAC-SHA256**
- Halaman **return/redirect** setelah pembayaran
- **Cek status transaksi** langsung ke API Duitku (sumber kebenaran status)
- Monitor riwayat transaksi (disimpan di `data/transactions.json`)

> Catatan penting: per **April 2026** semua signature Duitku memakai **HMAC-SHA256**
> (API key sebagai secret, output hex lowercase). MD5 dan SHA256 biasa sudah obsolete.
> Kode di proyek ini sudah memakai formula terbaru.

## 1. Persiapan

- Node.js ≥ 18
- Akun merchant Duitku + proyek sandbox di https://passport.duitku.com/merchant/Project
  (ambil **Merchant Code** dan **API Key** dari halaman proyek)

## 2. Instalasi

```bash
npm install
cp .env.example .env
# lalu edit .env, isi DUITKU_MERCHANT_CODE dan DUITKU_API_KEY
```

## 3. Jalankan

```bash
npm start
# buka http://localhost:3000
```

## 4. Supaya callback bisa diterima (wajib untuk verifikasi)

Server Duitku mengirim callback via HTTP POST ke URL **publik**. Saat development,
gunakan tunnel seperti ngrok:

```bash
ngrok http 3000
```

Lalu set di `.env`:

```
APP_BASE_URL=https://abcd1234.ngrok-free.app
```

Restart server. `callbackUrl` dan `returnUrl` otomatis memakai base URL ini.
Endpoint callback: `POST {APP_BASE_URL}/callback` — wajib membalas HTTP 200.

## 5. Uji transaksi di sandbox

- Buat transaksi dari halaman utama, pilih metode (mis. VA/QRIS).
- Untuk Virtual Account, gunakan halaman demo sukses Duitku:
  https://sandbox.duitku.com/payment/demo/demosuccesstransaction.aspx
- Kartu kredit uji: VISA `4000 0000 0000 0044`, exp `03/33`, CVV `123`.
- Setelah bayar, callback masuk → status di monitor berubah SUCCESS.

## 6. Formula signature (HMAC-SHA256, key = API Key)

| Proses            | stringToSign                                  |
|-------------------|-----------------------------------------------|
| Get Payment Method| merchantCode + amount + datetime              |
| Request Transaksi | merchantCode + merchantOrderId + paymentAmount|
| Callback (verif)  | merchantCode + amount + merchantOrderId       |
| Cek Transaksi     | merchantCode + merchantOrderId                |

## 7. Pindah ke production

- Ubah `DUITKU_ENV=production` di `.env` dan pakai kredensial proyek production.
- Whitelist IP outgoing Duitku bila server memakai firewall (lihat dokumentasi callback).
- Ganti penyimpanan `data/transactions.json` dengan database sungguhan.

## Struktur proyek

```
duitku-verify/
├── server.js            # Express: route API, callback, return
├── lib/duitku.js        # Signature HMAC-SHA256 + pemanggilan API Duitku
├── lib/store.js         # Penyimpanan transaksi sederhana (JSON)
├── public/index.html    # Form transaksi + monitor
├── public/return.html   # Halaman redirect setelah bayar
├── .env.example
└── package.json
```
